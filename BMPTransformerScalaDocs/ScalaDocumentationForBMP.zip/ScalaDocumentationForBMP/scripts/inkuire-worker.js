importScripts("inkuire.js");
WorkerMain.main();
